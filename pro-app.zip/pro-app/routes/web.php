<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\HobbyController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('create-departments',[DepartmentController::class,'create']);
Route::post('store-departments',[DepartmentController::class,'store']);
Route::get('show-departments',[DepartmentController::class,'show']);
Route::get('edit-departments/{id}',[DepartmentController::class,'edit']);
Route::post('update-departments/{id}',[DepartmentController::class,'update']);
Route::get('delete-departments/{id}',[DepartmentController::class,'delete']); 

//Route for controll hobby 
Route::get('create-hobby',[HobbyController::class,'create']);
Route::post('store-hobby',[HobbyController::class,'storehobby']);
Route::get('edit-hobby/{id}',[HobbyController::class,'edit']);
Route::post('update-hobby/{id}',[HobbyController::class,'update']);
Route::get('delete-hobby/{id}',[HobbyController::class,'delete']);

Route::get('create-new-member',[HobbyController::class,'createmember']);
Route::post('store-new-member',[HobbyController::class,'storemember']);
Route::get('choose-hobbies/{id}',[HobbyController::class,'choose']);
Route::post('store-new-hobby',[HobbyController::class,'selecthobby']);
Route::get('delete-hobby/{id}',[HobbyController::class,'deletehobbies']);