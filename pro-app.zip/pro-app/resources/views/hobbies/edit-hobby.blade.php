<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Hobby</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h3 class="text-center">Insert newUpdate existing hobby in the list</h3>
        <form action="{{url('update-hobby/'.$hobby->id)}}" method="post" class="form">
            @csrf
            <div>
                <label for="" class="form-group">Hobby</label>
                <input type="text" name="hobby" value="{{$hobby->hobby}}" class="form-control" required>
            </div>

            <div>
                <button type="submit" class="btn btn-success mt-3 center">Update hoobby</button>
            </div>
        </form>
       
    </div>
</body>

</html>