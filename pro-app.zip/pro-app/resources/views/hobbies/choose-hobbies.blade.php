<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Hobbies</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>

<body>

    <div class="container">
        <h3 class="text-center">Select different hobbies</h3>
        <form action="{{ url('store-new-hobby')}}" method="post" class="form m-4">
            @csrf
            <div>
                <label for="" class="form-group">Member Name</label>
                <input type="text" name="name" value="{{ $obj_person->id}}" class="form-control">
            </div>

            @foreach($obj_hobby as $hobby)

            @if ($obj_select->contains('h_id', $hobby->id))
            {{-- Skip rendering the checkbox --}}
            @else
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" name="hobbies[]" class="form-check-input"
                        value="{{ $hobby->id }}">{{$hobby->hobby}}
                </label>
            </div>
            @endif


            @endforeach

            <div>
                <button type="submit" class="btn btn-success mt-3 center">Select Hobbies</button>
            </div>
        </form>

        <div>

            <table class="table table-striped">
                <thead class="text-center">
                    <tr>
                        <td>Name</td>
                        <td>Hobbies </td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody class="text-center">
                    @foreach($obj_select as $item)
                    @foreach($obj_hobby as $h)
                    @if(($item->h_id == $h->id) && ($item->p_id == $obj_person->id))
                    <tr>
                        <td> {{$obj_person->name}}</td>
                        <td>{{ $h->hobby }} </td>

                        <td>
                            <a href="{{ url('delete-hobby/'.$item->id)}}" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                    @endif
                    @endforeach
                    @endforeach
                </tbody>
            </table>

        </div>




    </div>
</body>

</html>