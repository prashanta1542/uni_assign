<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Person</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h3 class="text-center">Entry new member</h3>
        <form action="{{ url('store-new-member')}}" method="post" class="form">
            @csrf
            <div>
                <label for="" class="form-group">Member Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div>
                <button type="submit" class="btn btn-success mt-3 center">Entry new member</button>
            </div>
        </form>

        <div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Name</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($obj as $member)
                    <tr>
                        <td>{{ $member->id }}</td>
                        <td>{{ $member->name }}</td>
                        <td>
                            <a href="{{ url('edit-member/'.$member->id)}}" class="btn btn-success">Edit</a>
                            <a href="{{ url('choose-hobbies/'.$member->id)}}" class="btn btn-info">See Different Option</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>