<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Department;
class DepartmentController extends Controller
{
   public function create(){
    return view('departments.create');
   }
   public function store(Request $req){
     echo $req->name;
     $department=new Department();
     $department->name = $req->name;
     $department->shortname = $req->shortname;
     $department->estAt = $req->estAt;

     if($department->save()){
        return redirect('show-departments');
     }else{
        echo " Failed to insert";
     }
   }

   public function show(){
    $department=Department::all();
    return view('departments.show',compact('department'));
   }

   public function edit($id){
    $department=Department::find($id);
    return view('departments.update',compact('department'));
   }

   public function update(Request $req, $id){
    
    $obj=Department::find($id);
    $obj->name = $req->name;
    $obj->shortname = $req->shortname;
    $obj->estAt = $req->estAt;
    if($obj->save()){
        return redirect('show-departments');
    }else{
        return redirect('edit-departments/'.$id);
    }
   }

   public function delete($id){
    $obj=Department::find($id);
    if($obj->delete()){
        return redirect('show-departments');
    }else{
        echo "failed to delete";
        return redirect('show-departments');
    }
   }
}
