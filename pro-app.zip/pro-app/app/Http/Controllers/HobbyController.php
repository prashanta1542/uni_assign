<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Hobby;
use App\Models\Person;
use App\Models\SelectedHobby;
class HobbyController extends Controller
{
    public function create(){
        $hobby=Hobby::all();
        return view('hobbies.createhobby',compact('hobby'));
    }
    public function storehobby(Request $req){
          $hobby=new Hobby();
          $hobby->hobby=$req->hobby;
          if($hobby->save()){
            return redirect('create-hobby');
          }
    }
   
    public function edit($id){
        $hobby=Hobby::find($id);
       return view('hobbies.edit-hobby',compact('hobby'));
       }

    public function update(Request $req,$id){
        $obj=Hobby::find($id);
        $obj->hobby=$req->hobby;
        if($obj->save()){
            return redirect('create-hobby');
        }
    }

    public function delete($id){
        $obj=Hobby::find($id);
        if($obj->delete()){
            return redirect('create-hobby');
        }else{
            echo "failed to delete";
            return redirect('show-departments');
        }
       }

    public function createmember(){
        $obj=Person::all();
        return view('hobbies.create-person',compact('obj'));
    }
    public function storemember(Request $req){
        $obj=new Person();
        $obj-> name = $req->name;
        if($obj->save()){
            return redirect('create-new-member');
        }
    }

    public function choose($id){
        $obj_person=Person::find($id);
        $obj_hobby=Hobby::all();
        $obj_select=SelectedHobby::where('p_id',$id)->get();

        return view('hobbies.choose-hobbies',compact('obj_person','obj_hobby','obj_select'));
    }

    public function selecthobby(Request $req)
{
    $name = $req->input('name');
    $selectedHobbies = $req->input('hobbies');
    $id=0;
    foreach ($selectedHobbies as $hobby) {
        $obj = new SelectedHobby();
        $obj->p_id = $name;
        $obj->h_id = $hobby;
       if( $obj->save()){
        $id=1;
       }
    }
    if($id==1){
        return redirect('choose-hobbies/'.$name);
    }
}

public function deletehobbies($id){
      $obj=SelectedHobby::find($id);
      $pid=$obj->p_id;
      if($obj->delete()){
          return redirect('choose-hobbies/'.$pid);
      }
}
  
}