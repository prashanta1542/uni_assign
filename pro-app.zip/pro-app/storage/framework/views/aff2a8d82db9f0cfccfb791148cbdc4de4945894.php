<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Department</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container">
        <h3 class="text-center">Insert new hobby in the list</h3>
        <form action="<?php echo e(url('store-hobby')); ?>" method="post" class="form">
            <?php echo csrf_field(); ?>
            <div>
                <label for="" class="form-group">Hobby</label>
                <input type="text" name="hobby" class="form-control" required>
            </div>

            <div>
                <button type="submit" class="btn btn-success mt-3 center">Create new hoobby</button>
            </div>
        </form>
        <div class="mt-3 mb-3">
            <table class="table table-striped">
                <thead class="text-center">
                    <tr>
                        <td>Id</td>
                        <td>Hobby</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php $__currentLoopData = $hobby; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->hobby); ?></td>
                        <td>
                            <a href="<?php echo e(url('edit-hobby/'.$item->id)); ?>" class="btn btn-success">Edit</a>
                            <a  class="btn btn-danger"data-toggle="modal"
                            data-target="<?php echo e('#myModal-'.$item->id); ?>">Delete</a>
                        </td>

                        <div class="modal fade" id="<?php echo e('myModal-'.$item->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">

                                    <div class="modal-body">
                                        Sure to delete ?
                                    </div>

                                    <div class="modal-footer">
                                        <a href="<?php echo e(url('delete-hobby/'.$item->id)); ?>" type="button"
                                            class="btn btn-danger">Yes</a>
                                        <button type="button" class="btn btn-warning" data-dismiss="modal">No</button>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel project\pro-app\resources\views/hobbies/createhobby.blade.php ENDPATH**/ ?>