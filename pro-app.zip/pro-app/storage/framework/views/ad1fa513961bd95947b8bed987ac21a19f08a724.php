<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show all department list</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container">
        
        <div class="row m-3">
                    <div class="col-6">
                    <h3 class='text-center'>List of all Departments</h3>
                    </div>
                    <div class="col-6">
                        <a href="<?php echo e('create-departments'); ?>" class='btn btn-success'> Create new departments</a>
                    </div>
        </div>
        <table class="table table-striped">
            <thead>
                <tr class="text-center">
                    <td>Department</td>
                    <td>Short aliase</td>
                    <td>Established at</td>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->shortname); ?></td>
                    <td><?php echo e($item->estAt); ?></td>
                    <td>
                        <a href="<?php echo e('edit-departments/'.$item->id); ?>" class="btn btn-secondary mr-2">Update</a>
                        <button class="btn btn-danger" data-toggle="modal"
                            data-target="<?php echo e('#myModal-'.$item->id); ?>">Delete</button>
                    </td>
                </tr>

                <div class="modal fade" id="<?php echo e('myModal-'.$item->id); ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">

                            <div class="modal-body">
                                Sure to delete ?
                            </div>

                            <div class="modal-footer">
                                <a href="<?php echo e('delete-departments/'.$item->id); ?>" type="button" class="btn btn-danger">Yes</a>
                                <button type="button" class="btn btn-warning" data-dismiss="modal">No</button>
                            </div>

                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel project\pro-app\resources\views/departments/show.blade.php ENDPATH**/ ?>