<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update existing Department</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <form action="<?php echo e(url('update-departments/'.$department->id)); ?>" method="post" class="form">
            <?php echo csrf_field(); ?> 
            <div>
                <label for="" class="form-group">Department Name</label>
                <input type="text" name="name"  value="<?php echo e($department->name); ?>" class="form-control" required>
            </div>
            <div>
                <label for="" class="form-group">Short alias</label>
                <input type="text" name="shortname"  value="<?php echo e($department->shortname); ?>"class="form-control" required>
            </div>
            <div>
                <label for="" class="form-group">Established at</label>
                <input type="date" name="estAt" value="<?php echo e($department->estAt); ?>" class="form-control" required>
            </div>
            <div>
                <button type="submit" class="btn btn-success mt-3 center">Update</button>
            </div>
        </form>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel project\pro-app\resources\views/departments/update.blade.php ENDPATH**/ ?>