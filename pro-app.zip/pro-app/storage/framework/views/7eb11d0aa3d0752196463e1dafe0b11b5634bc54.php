<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Person</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h3 class="text-center">Entry new member</h3>
        <form action="<?php echo e(url('store-new-member')); ?>" method="post" class="form">
            <?php echo csrf_field(); ?>
            <div>
                <label for="" class="form-group">Member Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div>
                <button type="submit" class="btn btn-success mt-3 center">Entry new member</button>
            </div>
        </form>

        <div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Name</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($member->id); ?></td>
                        <td><?php echo e($member->name); ?></td>
                        <td>
                            <a href="<?php echo e(url('edit-member/'.$member->id)); ?>" class="btn btn-success">Edit</a>
                            <a href="<?php echo e(url('choose-hobbies/'.$member->id)); ?>" class="btn btn-info">See Different Option</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel project\pro-app\resources\views/hobbies/create-person.blade.php ENDPATH**/ ?>